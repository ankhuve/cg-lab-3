#include "MyVector.h"

using namespace MyMathLibrary;

///YOUR CODE FROM ANIMATION TRACK LAB 2 HERE